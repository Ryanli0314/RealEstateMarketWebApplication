from flask import Flask, url_for, render_template, request, redirect, session, flash, jsonify
from werkzeug.utils import secure_filename
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
import json, flask_login, datetime, requests, base64
from hashlib import sha256
from models import *
from io import BytesIO
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
import matplotlib
matplotlib.use('Agg')  # Use a non-interactive backend
import matplotlib.pyplot as plt
import io
import os
import base64
import random
from bokeh.embed import components
from bokeh.plotting import figure
import imghdr
from key import key



global uploaded_data
uploaded_data = None

app = Flask(__name__)
app.secret_key = "9773e89f69e69285cf11c10cbc44a37945f6abbc5d78d5e20c2b1b0f12d75ab7"

# Login
login_manager = flask_login.LoginManager()
login_manager.init_app(app)

# data files
global USER_CREDENTIALS, USER_PREDICTIONS
USER_CREDENTIALS = './static/users/users.json'
USER_PREDICTIONS = './static/users/user_predict.json'


@login_manager.user_loader
def load_user(user_id):
    users = pd.read_json(USER_CREDENTIALS, orient='index')
    if user_id in users.index:
        user_data = users.loc[user_id]
        return User(user_data['username'], user_data['email'], user_data['password'])
    return None


@app.route('/', methods=['GET', 'POST'])
def index():
    regions = region_list()
    selected_region = None
    basic_info_str = None
    other_info_results = None

    if request.method == 'POST':
        selected_region = request.form.get('region')
        basic_info_str = basic_info(selected_region)
        other_info_results = other_info(selected_region)  # Use selected_region for other_info
    
    return render_template('index.html', regions=regions, basic_info_str=basic_info_str, other_info_results=other_info_results)


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')  # Capture email from the form
        password = request.form.get('password')
        password_hash = sha256(password.encode('utf-8')).hexdigest()

        # Load existing users
        users_df = pd.read_json(USER_CREDENTIALS, orient='index')

        # Check if the username already exists
        if username in users_df['username'].values:
            flash('Username already exists!', 'error')
            return render_template('signup.html', msg='username')

        # Create new user data
        new_user_data = {
            'username': username,
            'email': email,  # Include email in new user data
            'password': password_hash
        }

        # Add new user to DataFrame
        users_df.loc[sha256(username.encode('utf-8')).hexdigest()] = new_user_data

        # Save updated DataFrame back to JSON
        users_df.to_json(USER_CREDENTIALS, orient='index')

        # flash('Account created successfully!', 'success')
        return redirect(url_for('login'))

    return render_template('signup.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    # when clikcing the login button:
    if request.method == 'POST' and 'login' in request.form:
        username = request.form['username']
        password = request.form['password']
        # obtain the hash
        userid = sha256(username.encode('utf-8')).hexdigest()
        password_hash = sha256(password.encode('utf-8')).hexdigest()

        # load the user as an User object
        user_json = pd.read_json(USER_CREDENTIALS).get(userid)
        user = User(user_json['username'], user_json['email'], user_json['password'])

        # if user does not exist or if password does not match
        if user is None or password_hash != user.password:
            return render_template('login.html', msg="mismatch")
        # else, login success; redirect to user page
        else:
            flask_login.login_user(user)
            #flash("You're logged in!")
            #return redirect(url_for('user', name=user.username))
            return redirect(url_for('index'))
    # when clikcing the signup button
    elif request.method == 'POST' and 'signup' in request.form:
        return redirect(url_for('signup'))
    return render_template('login.html', msg=request.args.get('msg'))

@app.get('/user/<name>')
@flask_login.login_required
def user(name):
    return render_template('user_profile.html', edit='No',
                           name=flask_login.current_user.username)

@app.post('/user/<name>')
@flask_login.login_required
def user_edit(name):
    user = flask_login.current_user
    if 'editEmail' in request.form:
        return render_template('user_profile.html', edit="Yes",
                               name=user.username)
    else:
        new_email = request.form['email']
        user_json = pd.read_json(USER_CREDENTIALS)
        user_json.loc['email', user.id] = new_email
        user_json.to_json(USER_CREDENTIALS)
        user = User(*user_json[user.id].values)
        return redirect(url_for('user', name=user.username))
    
@app.route('/user/<name>/change_password', methods=['POST'])
@flask_login.login_required
def change_password(name):
    current_password = request.form['current_password']
    new_password = request.form['new_password']
    user = flask_login.current_user

    current_password_hash = sha256(current_password.encode('utf-8')).hexdigest()

    if current_password_hash != user.password:
        # flash('Current password is incorrect!', 'error')
        return redirect(url_for('user', name=name))

    new_password_hash = sha256(new_password.encode('utf-8')).hexdigest()

    # Update password in the DataFrame
    users_df = pd.read_json(USER_CREDENTIALS, orient='index')
    user_id = sha256(user.username.encode('utf-8')).hexdigest()
    users_df.loc[user_id, 'password'] = new_password_hash
    users_df.to_json(USER_CREDENTIALS, orient='index')

     # flash('Password changed successfully!', 'success')
    return redirect(url_for('user', name=name))

    
@app.route('/delete_account', methods=['POST'])
@flask_login.login_required
def delete_account():
    user = flask_login.current_user

    # Load existing users
    users_df = pd.read_json(USER_CREDENTIALS, orient='index')

    # Remove user data from DataFrame
    user_id = sha256(user.username.encode('utf-8')).hexdigest()
    if user_id in users_df.index:
        users_df = users_df.drop(user_id)

        # Save updated DataFrame back to JSON
        users_df.to_json(USER_CREDENTIALS, orient='index')

        # Log the user out
        flask_login.logout_user()

        # flash('Account deleted successfully!', 'success')
        return redirect(url_for('index'))
    else:
        # flash('An error occurred. Please try again.', 'error')
        return redirect(url_for('user', name=user.username))

@app.route("/logout")
@flask_login.login_required
def logout():
    flask_login.logout_user()
    return redirect(url_for('index'))

@app.route('/about')
def about():
    return render_template('about.html')



####################### Calculators ##########################

@app.route('/calculator', methods=['GET', 'POST'])
def calculator():
    if request.method == 'POST':
        # Get user input from the form
        ai = int(request.form['annual_income'])
        md = int(request.form['monthly_debts'])
        dp = int(request.form['down_payment'])
        dti = float(request.form['debt_to_income'])
        annual_discount_rate = float(request.form['annual_discount_rate'])
        num_months = int(request.form['loan_term'])
        
        # Define present_value formula
        def present_value(cash_flow, annual_discount_rate, num_months):
            monthly_discount_rate = annual_discount_rate / 12 / 100
            pv = 0
            for t in range(1, num_months + 1):
                pv += cash_flow / (1 + monthly_discount_rate)**t
            return pv
            
        # Calculate affordability
        cash_flow = (ai * (dti / 100)) / 12 - md
        result = dp + present_value(cash_flow, annual_discount_rate, num_months)

        # Render the result on the calculator.html template
        return render_template('calculator.html', result=round(result), monthly_payment=round(cash_flow))

    # If it's a GET request, render the calculator form
    return render_template('calculator.html')

@app.route('/mortgage-calculator', methods=['GET', 'POST'])
def mortgageCalculator():
    if request.method == 'POST':
        # Get user input from the form
        hp = int(request.form['home_price'])
        pt = int(request.form['property_tax'])
        dp = int(request.form['down_payment'])
        dti = float(request.form['home_insurance'])
        interest_rate = float(request.form['interest_rate'])
        loan_program = int(request.form['loan_term'])

        loan_amount = hp - dp
        num_months = loan_program * 12
        monthly_interest_rate = interest_rate / 12 / 100
        monthly_payment = loan_amount * monthly_interest_rate * (1 + monthly_interest_rate)**num_months / ((1 + monthly_interest_rate)**num_months - 1)
        monthly_property_tax = pt / 12
        monthly_home_insurance = dti / 12
        monthly_payment += monthly_property_tax + monthly_home_insurance

        # Render the result on the calculator.html template
        return render_template('mortgage-calculator.html', result=round(monthly_payment))

    # If it's a GET request, render the calculator form
    return render_template('mortgage-calculator.html')

@app.route('/debt-calculator', methods=['GET', 'POST'])
def debtCalculator():
    if request.method == 'POST':
        # Get user input from the form
        ai = int(request.form['annual_income'])
        creditCardPayments = int(request.form['creditCardPayments'])
        carLoanPayments = int(request.form['carLoanPayments'])
        studentLoanPayments = int(request.form['studentLoanPayments'])
        alimonyPayments = int(request.form['alimonyPayments'])
        secondaryHomeExpenses = int(request.form['secondaryHomeExpenses']) 
        otherDebtPayments = int(request.form['otherDebtPayments']) 

        monthly_income = float(ai / 12);
        debtToIncomeRatio = float(creditCardPayments + carLoanPayments + studentLoanPayments + alimonyPayments + secondaryHomeExpenses + otherDebtPayments) / monthly_income * 100

        # Render the result on the calculator.html template
        return render_template('debt-calculator.html', result=round(debtToIncomeRatio, 2))

    # If it's a GET request, render the calculator form
    return render_template('debt-calculator.html')


#########################################################################################

def region_list():
    file_path = 'static/data/Metro_zhvi_uc_sfrcondo_tier_0.33_0.67_sm_sa_month.csv'
    data = pd.read_csv(file_path)
    region_list = sorted(data['RegionName'].unique().tolist())  # Sort the list
    return region_list

def basic_info(region_name_sel):
    # Load the data
    file_name = 'Metro_zhvi_uc_sfrcondo_tier_0.33_0.67_sm_sa_month.csv'
    price_data = load_and_filter_data(region_name_sel, file_name)
    
    price_data_trans = prepare_data(price_data)

    # Extracting the prices
    most_recent_price = price_data_trans.iloc[-1]['Price']
    mean_price = price_data_trans['Price'].mean()
    formatted_price = "{:,.0f}".format(mean_price)
    one_year_earlier_price = price_data_trans.iloc[-13]['Price']

    # Calculating the year-on-year percentage change
    percentage_change = ((most_recent_price - one_year_earlier_price) / one_year_earlier_price) * 100
    formatted_percent = "{:.1f}".format(abs(percentage_change))
    
    updown = "up"
    if percentage_change < 0:
        updown = "down"
    
    # Get pending days
    file_name = 'Metro_med_doz_pending_uc_sfrcondo_month.csv'
    pend_data = load_and_filter_data(region_name_sel, file_name)
    most_recent_pending_days = "NaN"
    pend_data_trans = []
    if len(pend_data) == 1:
        pend_data_trans = prepare_data(pend_data, 'Pending')

    # Create a list to hold each line of information
    info_lines = [f"The average {region_name_sel} home value is ${formatted_price},"]

    # Check if pend_data_trans is empty or the required data is not available
    if len(pend_data_trans) >= 13:
        most_recent_pending_days = pend_data_trans.iloc[-1]['Pending']
        if most_recent_pending_days is not None:
            info_lines.append(f"{updown} {formatted_percent}% over the past year and goes to pending in around {most_recent_pending_days} days.")
        else:
            info_lines.append(f"{updown} {formatted_percent}% over the past year.")
    else:
        # Only include home value information if pending data is not available
        info_lines.append(f"{updown} {formatted_percent}% over the past year.")

    return info_lines


# F1: For-sale inventory (last month)
inven = "Metro_invt_fs_uc_sfrcondo_sm_month"
# F2: New Listings
new = "Metro_new_listings_uc_sfrcondo_sm_month"
# F3: Percent of sales over list price
over = "Metro_pct_sold_above_list_uc_sfrcondo_sm_month"

file_name_list = [inven, new, over]
base_path = '%s.csv'

def other_info (region_name):
    # F1: For-sale inventory (last month)
    inven = "Metro_invt_fs_uc_sfrcondo_sm_month"
    # F2: New Listings
    new = "Metro_new_listings_uc_sfrcondo_sm_month"
    # F3: Percent of sales over list price
    over = "Metro_pct_sold_above_list_uc_sfrcondo_sm_month"

    file_name_list = [inven, new, over]
    base_path = '%s.csv'
    
    # F1: Load inven data
    file_path = base_path%file_name_list[0]
    inven_data = load_and_filter_data(region_name, file_path)
    inven_str = "%s For Sale Inventory (%s)"

    if len(inven_data) != 1:
        inven_str = inven_str%("NaN", "NaN")
    else:
        inven_data_trans = prepare_data(inven_data, "Inventory")
        inven_data_trans['Inventory'] = inven_data_trans['Inventory'].astype(int)
        monthly_inven = inven_data_trans['Inventory'].iloc[-1]
        monthly_inven = "{:,.0f}".format(monthly_inven)
        latest_month = inven_data_trans['Date'].iloc[-1].strftime("%B %d, %Y")
        inven_str = inven_str%(monthly_inven, latest_month)
    
    # F2: Load new listing data
    file_path = base_path%file_name_list[1]
    listing_data = load_and_filter_data(region_name, file_path)
    listing_str = "%s New Listings (%s)"

    if len(listing_data) != 1:
        inven_str = inven_str%("NaN", "NaN")
    else:
        listing_data_trans = prepare_data(listing_data, "New_Listings")
        listing_data_trans['New_Listings'] = listing_data_trans['New_Listings'].astype(int)
        new_listings = listing_data_trans['New_Listings'].iloc[-1]
        new_listings = "{:,.0f}".format(new_listings)
        latest_month = listing_data_trans['Date'].iloc[-1].strftime("%B %d, %Y")
        listing_str = listing_str%(new_listings, latest_month)
        
    # F3: Load sales over listg data
    file_path = base_path%file_name_list[2]
    over_data = load_and_filter_data(region_name, file_path)
    over_str = "%s%% Percent of sales over list price (%s)"

    if len(over_data) != 1:
        over_str = over_str%("NaN", "NaN")
    else:
        over_data_trans = prepare_data(over_data, "Over_Price")
        over_data_trans['Over_Price'] = over_data_trans['Over_Price']
        over_price = (over_data_trans['Over_Price'].iloc[-1])*100
        over_price = "{:.1f}".format(over_price)
        latest_month = over_data_trans['Date'].iloc[-1].strftime("%B %d, %Y")
        over_str = over_str%(over_price, latest_month)
    
        
    return (inven_str, listing_str, over_str)
        
    







def load_and_filter_data(search_word, file_name):

    search_clean = search_word.lower().title()
    if ',' in search_word:
        search_clean = search_word
    file_path = f'static/data/{file_name}'
    data = pd.read_csv(file_path)
    data = data[data['RegionName'].str.contains(search_clean)]
    return data

def prepare_data(region_data, file_type = 'Price'):
    data_tran = region_data.drop(columns=['RegionID', 'SizeRank', 'RegionName', 'RegionType', 'StateName']).T
    data_tran.columns = [file_type]
    data_tran['Date'] = pd.to_datetime(data_tran.index)
    data_tran['Date_Num'] = data_tran['Date'].map(pd.Timestamp.toordinal)
    col_name = data_tran.columns[0]
    data_tran.dropna(subset=[col_name], inplace=True)

    return data_tran


def find_recovery_start_date(data, start_year, duration):

    # Filter the data to start from the specified year
    filtered_data = data[data['Date'].dt.year >= start_year]

    # Initialize variables
    recovery_start_index = None
    consistent_rise = True

    # Iterate through the data to find the recovery point
    for i in range(duration, len(filtered_data)):
        # Check if prices have consistently risen over the specified duration
        consistent_rise = all(filtered_data['Price'].iloc[i - j] > filtered_data['Price'].iloc[i - j - 1]
                              for j in range(1, duration + 1))

        if consistent_rise:
            recovery_start_index = i - duration
            break

    # Get the recovery date
    if recovery_start_index is not None:
        recovery_date = filtered_data['Date'].iloc[recovery_start_index]
        return recovery_date.strftime('%Y-%m-%d')
    else:
        return "No recovery point identified within the dataset"
    

def filtered_data(data, start_date):
    # Filter the data to start from the specified year
    filtered_data = data[data['Date']>= start_date]
    filtered_data = filtered_data.reset_index(drop=True)
    return filtered_data

def train_model(data):
    model = LinearRegression()
    model.fit(data[['Date_Num']], data['Price'])
    
    return model

def create_graph(region_name, file_name, file_descriptions):
    region_data = load_and_filter_data(region_name, file_name)
    region_data_transposed = prepare_data(region_data)

    # Check if region_data is empty or not structured as expected
    if region_data.empty or len(region_data.columns) < 2:  # Adjust condition based on your data structure
        print("Error: Data is empty or not in the expected format.")
        return None  # Handle this situation appropriately

    # Example usage of the function

    recovery_date_post_2008 = find_recovery_start_date(region_data_transposed, 2009, duration=12)
    post_2008_data = filtered_data(region_data_transposed, recovery_date_post_2008)

    recovery_date_post_covid = find_recovery_start_date(region_data_transposed, 2020, duration=12)
    post_covid_data = filtered_data(region_data_transposed, recovery_date_post_covid)

    recovery_date_post_2022 = find_recovery_start_date(region_data_transposed, 2023, duration=3)
    if len(recovery_date_post_2022) != 10:
        recovery_date_post_2022 = '2023-03-31'
    post_2022_data = filtered_data(region_data_transposed, recovery_date_post_2022)

    # Predict the price for the next month using all four models
    latest_date = region_data_transposed['Date'].max()
    next_month = latest_date + pd.DateOffset(months=1)
    next_month_num = next_month.toordinal()

    # Create and train four linear regression models
    model_all_data = train_model(region_data_transposed)
    model_post_2008 = train_model(post_2008_data)
    model_post_covid = train_model(post_covid_data)
    model_post_2022 = train_model(post_2022_data)

    next_month_prediction_all = model_all_data.predict(np.array([[next_month_num]]))
    next_month_prediction_post_2008 = model_post_2008.predict(np.array([[next_month_num]]))
    next_month_prediction_post_covid = model_post_covid.predict(np.array([[next_month_num]]))
    next_month_prediction_post_2022 = model_post_2022.predict(np.array([[next_month_num]]))

    # Plotting the graph
    plt.figure(figsize=(12, 6))
    plt.plot(region_data_transposed['Date'], region_data_transposed['Price'], label='Actual Prices')

    # Mark the predictions
    plt.scatter(next_month, next_month_prediction_all, color='red', label='Next Month Prediction (All Data)')
    plt.scatter(next_month, next_month_prediction_post_2008, color='green', label='Next Month Prediction (Post-2008)')
    plt.scatter(next_month, next_month_prediction_post_covid, color='blue', label='Next Month Prediction (Post-COVID)')
    plt.scatter(next_month, next_month_prediction_post_2022, color='purple', label='Next Month Prediction (Post-2022)')
    
    search_new = region_data['RegionName'].iloc[0]
    
    # Get the descriptive file name
    descriptive_file_name = file_descriptions.get(file_name, file_name)
    
    title_text = f"{search_new} Real Estate Prices with Predictions\nFile: {descriptive_file_name}"
    plt.title(title_text)
    plt.xlabel('Date')
    plt.ylabel('Price')
    plt.legend()

    # Generate the image file name dynamically
    image_file_name = f"graph_{region_name.replace(' ', '_')}.jpg"

    # Save the graph to the specified file
    plt.savefig(f'static/img/{image_file_name}')
    
    print("Generated Image File Name:", image_file_name)

    # Return the image file name
    return image_file_name


# Assuming the necessary helper functions are defined elsewhere:
# find_recovery_start_date, filtered_data, and train_model

def generate_predictions_and_analysis(region_data_transposed):
    # Function to train linear regression model
    def train_model(data):
        model = LinearRegression()
        model.fit(data[['Date_Num']], data['Price'])
        return model

    # Calculate recovery start dates for different periods
    recovery_date_post_2008 = find_recovery_start_date(region_data_transposed, 2009, duration=12)
    recovery_date_post_covid = find_recovery_start_date(region_data_transposed, 2020, duration=12)

    recovery_date_post_2022 = find_recovery_start_date(region_data_transposed, 2023, duration=3)
    if len(recovery_date_post_2022) != 10:
        recovery_date_post_2022 = '2023-03-31'

    # Filter data based on recovery dates
    post_2008_data = filtered_data(region_data_transposed, recovery_date_post_2008)
    post_covid_data = filtered_data(region_data_transposed, recovery_date_post_covid)
    post_2022_data = filtered_data(region_data_transposed, recovery_date_post_2022)

    # Train models
    model_all_data = train_model(region_data_transposed)
    model_post_2008 = train_model(post_2008_data)
    model_post_covid = train_model(post_covid_data)
    model_post_2022 = train_model(post_2022_data)

    # Predictions for the next month
    latest_date = region_data_transposed['Date'].max()
    next_month = latest_date + pd.DateOffset(months=1)
    next_month_num = next_month.toordinal()

    predictions = {
        "All Data": model_all_data.predict(np.array([[next_month_num]]))[0],
        "Post-2008": model_post_2008.predict(np.array([[next_month_num]]))[0],
        "Post-COVID": model_post_covid.predict(np.array([[next_month_num]]))[0],
        "Post-2022": model_post_2022.predict(np.array([[next_month_num]]))[0],
    }

    # One year before the next month for YoY comparison
    one_year_before_next_month = next_month - pd.DateOffset(years=1)
    one_year_before_price = region_data_transposed.loc[region_data_transposed['Date'] == one_year_before_next_month, 'Price']
    one_year_before_price = one_year_before_price.values[0] if not one_year_before_price.empty else np.nan

    # Compile analysis results
    analysis_results = []
    for model_name, model in {"All Data": model_all_data, "Post-2008": model_post_2008, "Post-COVID": model_post_covid, "Post-2022": model_post_2022}.items():
        prediction = predictions[model_name]
        yoy_percentage_diff_str = "N/A"
        if not np.isnan(one_year_before_price):
            yoy_percentage_diff = ((prediction - one_year_before_price) / one_year_before_price) * 100
            yoy_percentage_diff_str = f"{yoy_percentage_diff:.2f}%"

        analysis_results.append({
            'model_name': model_name,
            'equation': f"Price = {model.intercept_:.3f} + {model.coef_[0]:.3f} * Date_Num",
            'predicted_price': f"${prediction:,.2f}",
            'yoy_diff': yoy_percentage_diff_str
        })

    return analysis_results


@app.route('/test', methods=['GET', 'POST'])
def test():
    image_path = None
    analysis_results = []  # Initialize as an empty list
    file_name = 'Metro_zhvi_uc_sfrcondo_tier_0.33_0.67_sm_sa_month.csv'
    
    # Load the JSON file for file descriptions
    with open(os.path.join(DATA_FOLDER, 'file_names.json')) as json_file:
        file_descriptions = json.load(json_file)

    # Retrieve the selected file name (string) from the session
    selected_file_name = session.get('selected_file', None)
    if selected_file_name:
        file_name = selected_file_name  # Use the selected file name

    if request.method == 'POST':
        search_term = request.form['search_term']
        search_data = load_and_filter_data(search_term, file_name )

        if search_data.empty:
            flash("Wrong input: No regions found with the given search term.", "error")
        else:
            if len(search_data) > 1:
                matching_regions = ', '.join(search_data['RegionName'].tolist())
                flash(f"Multiple regions found: {matching_regions}. Automatically selected the first one.", "warning")
                region_name = search_data['RegionName'].iloc[0]
                search_data = load_and_filter_data(region_name, file_name)

            else:
                region_name = search_term

            # Prepare data and generate analysis results
            region_data_transposed = prepare_data(search_data)
            analysis_results = generate_predictions_and_analysis(region_data_transposed)

            # Generate graph
            image_file_name = create_graph(region_name, file_name, file_descriptions)
            image_path = f'/static/img/{image_file_name}'

    return render_template('test.html', analysis_results=analysis_results, image_path=image_path)



DATA_FOLDER = os.path.join('static', 'data')
ALLOWED_EXTENSIONS = {'csv'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def list_files():
    return [f for f in os.listdir(DATA_FOLDER) if f.startswith('Metro_zhvi_')]
from flask import session  # Import session


@app.route('/file_select', methods=['GET', 'POST'])
def file_select():
    # Load the JSON file
    with open(os.path.join(DATA_FOLDER, 'file_names.json')) as json_file:
        file_descriptions = json.load(json_file)
    if request.method == 'POST':
        selected_file = request.form.get('file_selection')
        if selected_file:
            session['selected_file'] = selected_file  # Store selected file in session
            flash(f"File in use: {file_descriptions.get(selected_file, selected_file)}", "info")

        # File upload handling
        if 'file_upload' in request.files:
            file = request.files['file_upload']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_path = os.path.join(DATA_FOLDER, filename)
                if os.path.exists(file_path):
                    flash("File already exists", "error")
                else:
                    try:
                        # Validate the file format and columns
                        df = pd.read_csv(file)
                        # Add your validation logic here
                        file.save(file_path)
                        flash("File upload: Success!", "success")
                    except Exception as e:
                        flash(f"Error processing file: {str(e)}", "error")

        return redirect(url_for('file_select'))

    files = list_files()
    files_with_descriptions = [(f, file_descriptions.get(f, f)) for f in file_descriptions.keys() if f in files]
    return render_template('file_select.html', files=files_with_descriptions)

@app.route('/next_page')
def next_page():
    # Implement your logic for the next page
    return "Next Page - Implement your functionality here"


# Main Driver Function 
if __name__ == "__main__":
    app.run(debug=True)